import { type RouteConfig, index, prefix, route } from "@react-router/dev/routes";

const devRoutes = import.meta.env.DEV ? prefix("dev", [route("components", "dev/components.tsx")]) : [];

export default [
  index("routes/home.tsx"),
  route("saved", "routes/saved.tsx"),
  route("settings", "routes/settings.tsx"),
  route("achievements", "routes/achievements.tsx"),
  ...devRoutes,
] satisfies RouteConfig;
