import { useState } from "react";
import { Link } from "react-router";
import type { Route } from "./+types/settings";
import { useLocalStorage } from "~/hooks/use-local-storage";
import { ArrowLeft, Trophy, Trash2 } from "lucide-react";
import classNames from "classnames";
import styles from "./settings.module.css";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Settings - VACA" },
    {
      name: "description",
      content: "Customize your vocabulary learning experience",
    },
  ];
}

const difficulties = ["Beginner", "Intermediate", "Advanced"];
const categories = ["Daily Use", "Business", "Academic"];

export default function Settings() {
  const [selectedDifficulties, setSelectedDifficulties] = useLocalStorage<string[]>(
    "vaca-difficulty-filter",
    difficulties,
  );
  const [selectedCategories, setSelectedCategories] = useLocalStorage<string[]>("vaca-category-filter", categories);
  const [streak, setStreak] = useLocalStorage<number>("vaca-streak", 0);
  const [wordsLearnedToday] = useLocalStorage<number>("vaca-words-today", 0);
  const [bookmarkedIds] = useLocalStorage<string[]>("vaca-bookmarks", []);
  const [learnedWordIds, setLearnedWordIds] = useLocalStorage<string[]>("vaca-learned-ids", []);

  const toggleDifficulty = (difficulty: string) => {
    if (selectedDifficulties.includes(difficulty)) {
      if (selectedDifficulties.length > 1) {
        setSelectedDifficulties(selectedDifficulties.filter((d) => d !== difficulty));
      }
    } else {
      setSelectedDifficulties([...selectedDifficulties, difficulty]);
    }
  };

  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      if (selectedCategories.length > 1) {
        setSelectedCategories(selectedCategories.filter((c) => c !== category));
      }
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  const resetProgress = () => {
    if (confirm("Are you sure you want to reset all progress? This cannot be undone.")) {
      setStreak(0);
      setLearnedWordIds([]);
    }
  };

  return (
    <div className={styles.settings}>
      <header className={styles.header}>
        <Link to="/" className={styles.backButton}>
          <ArrowLeft size={24} />
        </Link>
        <h1 className={styles.title}>Settings</h1>
      </header>

      <main className={styles.main}>
        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Your Progress</h2>
          <div className={styles.stats}>
            <div className={styles.statCard}>
              <p className={styles.statValue}>{streak}</p>
              <p className={styles.statLabel}>Day Streak</p>
            </div>
            <div className={styles.statCard}>
              <p className={styles.statValue}>{wordsLearnedToday}</p>
              <p className={styles.statLabel}>Today</p>
            </div>
            <div className={styles.statCard}>
              <p className={styles.statValue}>{bookmarkedIds.length}</p>
              <p className={styles.statLabel}>Saved</p>
            </div>
            <div className={styles.statCard}>
              <p className={styles.statValue}>{learnedWordIds.length}</p>
              <p className={styles.statLabel}>Total Learned</p>
            </div>
          </div>
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Word Filters</h2>

          <div className={styles.settingRow}>
            <div className={styles.settingInfo}>
              <p className={styles.settingLabel}>Difficulty Levels</p>
              <p className={styles.settingDescription}>Choose which difficulty levels to include</p>
            </div>
          </div>
          <div className={styles.filterGroup}>
            {difficulties.map((difficulty) => (
              <button
                key={difficulty}
                className={classNames(styles.filterButton, {
                  [styles.active]: selectedDifficulties.includes(difficulty),
                })}
                onClick={() => toggleDifficulty(difficulty)}
              >
                {difficulty}
              </button>
            ))}
          </div>

          <div className={styles.settingRow} style={{ marginTop: "var(--space-5)" }}>
            <div className={styles.settingInfo}>
              <p className={styles.settingLabel}>Categories</p>
              <p className={styles.settingDescription}>Select word categories to focus on</p>
            </div>
          </div>
          <div className={styles.filterGroup}>
            {categories.map((category) => (
              <button
                key={category}
                className={classNames(styles.filterButton, {
                  [styles.active]: selectedCategories.includes(category),
                })}
                onClick={() => toggleCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </section>

        <section className={styles.section}>
          <h2 className={styles.sectionTitle}>Quick Actions</h2>

          <div className={styles.settingRow}>
            <div className={styles.settingInfo}>
              <p className={styles.settingLabel}>View Achievements</p>
              <p className={styles.settingDescription}>See your learning badges and milestones</p>
            </div>
            <Link to="/achievements" className={styles.actionButton}>
              <Trophy size={18} />
              View
            </Link>
          </div>

          <div className={styles.settingRow}>
            <div className={styles.settingInfo}>
              <p className={styles.settingLabel}>Reset Progress</p>
              <p className={styles.settingDescription}>Clear all learning statistics and start fresh</p>
            </div>
            <button className={classNames(styles.actionButton, styles.dangerButton)} onClick={resetProgress}>
              <Trash2 size={18} />
              Reset
            </button>
          </div>
        </section>
      </main>
    </div>
  );
}
