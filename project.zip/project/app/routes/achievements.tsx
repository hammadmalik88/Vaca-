import { Link } from "react-router";
import type { Route } from "./+types/achievements";
import { useLocalStorage } from "~/hooks/use-local-storage";
import { ArrowLeft, Award, BookOpen, Flame, Star, Target, Trophy, Zap } from "lucide-react";
import classNames from "classnames";
import styles from "./achievements.module.css";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Achievements - VACA" },
    {
      name: "description",
      content: "Your learning achievements and badges",
    },
  ];
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<{ size?: number }>;
  requirement: number;
  category: "streak" | "words" | "bookmarks" | "difficulty";
}

const achievements: Achievement[] = [
  {
    id: "first-day",
    title: "First Steps",
    description: "Complete your first day of learning",
    icon: Star,
    requirement: 1,
    category: "streak",
  },
  {
    id: "week-streak",
    title: "Week Warrior",
    description: "Maintain a 7-day learning streak",
    icon: Flame,
    requirement: 7,
    category: "streak",
  },
  {
    id: "month-streak",
    title: "Monthly Master",
    description: "Achieve a 30-day learning streak",
    icon: Trophy,
    requirement: 30,
    category: "streak",
  },
  {
    id: "ten-words",
    title: "Vocabulary Builder",
    description: "Learn 10 new words",
    icon: BookOpen,
    requirement: 10,
    category: "words",
  },
  {
    id: "fifty-words",
    title: "Word Enthusiast",
    description: "Learn 50 new words",
    icon: Zap,
    requirement: 50,
    category: "words",
  },
  {
    id: "hundred-words",
    title: "Lexicon Legend",
    description: "Learn 100 new words",
    icon: Award,
    requirement: 100,
    category: "words",
  },
  {
    id: "first-bookmark",
    title: "Collector",
    description: "Save your first word",
    icon: Target,
    requirement: 1,
    category: "bookmarks",
  },
  {
    id: "ten-bookmarks",
    title: "Curator",
    description: "Save 10 words to your collection",
    icon: Star,
    requirement: 10,
    category: "bookmarks",
  },
];

export default function Achievements() {
  const [streak] = useLocalStorage<number>("vaca-streak", 0);
  const [learnedWordIds] = useLocalStorage<string[]>("vaca-learned-ids", []);
  const [bookmarkedIds] = useLocalStorage<string[]>("vaca-bookmarks", []);

  const getProgress = (achievement: Achievement): { current: number; unlocked: boolean } => {
    let current = 0;
    switch (achievement.category) {
      case "streak":
        current = streak;
        break;
      case "words":
        current = learnedWordIds.length;
        break;
      case "bookmarks":
        current = bookmarkedIds.length;
        break;
    }
    return {
      current,
      unlocked: current >= achievement.requirement,
    };
  };

  return (
    <div className={styles.achievements}>
      <header className={styles.header}>
        <Link to="/settings" className={styles.backButton}>
          <ArrowLeft size={24} />
        </Link>
        <h1 className={styles.title}>Achievements</h1>
      </header>

      <main className={styles.main}>
        <div className={styles.grid}>
          {achievements.map((achievement) => {
            const { current, unlocked } = getProgress(achievement);
            const Icon = achievement.icon;

            return (
              <div
                key={achievement.id}
                className={classNames(styles.badge, unlocked ? styles.unlocked : styles.locked)}
              >
                <div className={styles.iconWrapper}>
                  <Icon size={40} />
                </div>
                <h3 className={styles.badgeTitle}>{achievement.title}</h3>
                <p className={styles.badgeDescription}>{achievement.description}</p>
                <p className={styles.progress}>{unlocked ? "✓ Unlocked" : `${current} / ${achievement.requirement}`}</p>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
