import { Link } from "react-router";
import type { Route } from "./+types/saved";
import { vocabularyDatabase } from "~/data/vocabulary";
import { useLocalStorage } from "~/hooks/use-local-storage";
import { ArrowLeft, Bookmark, BookmarkX, Volume2 } from "lucide-react";
import styles from "./saved.module.css";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "Saved Words - VACA" },
    {
      name: "description",
      content: "Your bookmarked vocabulary words",
    },
  ];
}

export default function Saved() {
  const [bookmarkedIds, setBookmarkedIds] = useLocalStorage<string[]>("vaca-bookmarks", []);

  const savedWords = vocabularyDatabase.filter((word) => bookmarkedIds.includes(word.id));

  const removeBookmark = (id: string) => {
    setBookmarkedIds(bookmarkedIds.filter((bookmarkId) => bookmarkId !== id));
  };

  const speak = (word: string) => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(word);
      utterance.lang = "en-US";
      utterance.rate = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className={styles.saved}>
      <header className={styles.header}>
        <Link to="/" className={styles.backButton}>
          <ArrowLeft size={24} />
        </Link>
        <h1 className={styles.title}>Saved Words</h1>
      </header>

      <main className={styles.main}>
        {savedWords.length === 0 ? (
          <div className={styles.emptyState}>
            <Bookmark className={styles.emptyIcon} size={64} />
            <h2 className={styles.emptyTitle}>No saved words yet</h2>
            <p className={styles.emptyText}>Bookmark words as you learn them to build your personal collection</p>
          </div>
        ) : (
          <div className={styles.grid}>
            {savedWords.map((word) => (
              <div key={word.id} className={styles.wordCard}>
                <div className={styles.cardHeader}>
                  <h3 className={styles.wordTitle}>{word.word}</h3>
                  <button
                    className={styles.removeButton}
                    onClick={() => removeBookmark(word.id)}
                    aria-label="Remove bookmark"
                  >
                    <BookmarkX size={20} />
                  </button>
                </div>
                <p className={styles.partOfSpeech}>{word.partOfSpeech}</p>
                <p className={styles.meaning}>{word.meaning}</p>
                <div className={styles.cardFooter}>
                  <div className={styles.badges}>
                    <span className={styles.badge}>{word.category}</span>
                    <span className={styles.difficultyBadge}>{word.difficulty}</span>
                  </div>
                  <button className={styles.speakerButton} onClick={() => speak(word.word)} aria-label="Pronounce word">
                    <Volume2 size={18} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
