import { useState, useEffect } from "react";
import { Link } from "react-router";
import type { Route } from "./+types/home";
import { vocabularyDatabase } from "~/data/vocabulary";
import { WordCard } from "~/components/word-card";
import { useSwipe } from "~/hooks/use-swipe";
import { useLocalStorage } from "~/hooks/use-local-storage";
import { Bookmark, Volume2, ChevronLeft, ChevronRight, Settings, Library, Flame } from "lucide-react";
import classNames from "classnames";
import styles from "./home.module.css";

export function meta({}: Route.MetaArgs) {
  return [
    { title: "VACA - Vocabulary Learning" },
    {
      name: "description",
      content: "Learn English vocabulary with a beautiful vintage book experience",
    },
  ];
}

export default function Home() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [bookmarkedIds, setBookmarkedIds] = useLocalStorage<string[]>("vaca-bookmarks", []);
  const [streak, setStreak] = useLocalStorage<number>("vaca-streak", 0);
  const [lastVisit, setLastVisit] = useLocalStorage<string>("vaca-last-visit", "");
  const [wordsLearnedToday, setWordsLearnedToday] = useLocalStorage<number>("vaca-words-today", 0);
  const [learnedWordIds, setLearnedWordIds] = useLocalStorage<string[]>("vaca-learned-ids", []);

  const currentWord = vocabularyDatabase[currentIndex];
  const isBookmarked = bookmarkedIds.includes(currentWord.id);

  useEffect(() => {
    const today = new Date().toDateString();
    if (lastVisit !== today) {
      const yesterday = new Date(Date.now() - 86400000).toDateString();
      if (lastVisit === yesterday) {
        setStreak(streak + 1);
      } else if (lastVisit) {
        setStreak(1);
      } else {
        setStreak(1);
      }
      setLastVisit(today);
      setWordsLearnedToday(0);
      setLearnedWordIds([]);
    }
  }, []);

  const handleNext = () => {
    const nextIndex = (currentIndex + 1) % vocabularyDatabase.length;
    setCurrentIndex(nextIndex);

    if (!learnedWordIds.includes(currentWord.id)) {
      setLearnedWordIds([...learnedWordIds, currentWord.id]);
      setWordsLearnedToday(wordsLearnedToday + 1);
    }
  };

  const handlePrevious = () => {
    const prevIndex = currentIndex === 0 ? vocabularyDatabase.length - 1 : currentIndex - 1;
    setCurrentIndex(prevIndex);
  };

  const swipeHandlers = useSwipe({
    onSwipeLeft: handleNext,
    onSwipeRight: handlePrevious,
  });

  const toggleBookmark = () => {
    if (isBookmarked) {
      setBookmarkedIds(bookmarkedIds.filter((id) => id !== currentWord.id));
    } else {
      setBookmarkedIds([...bookmarkedIds, currentWord.id]);
    }
  };

  const speak = () => {
    if ("speechSynthesis" in window) {
      const utterance = new SpeechSynthesisUtterance(currentWord.word);
      utterance.lang = "en-US";
      utterance.rate = 0.8;
      window.speechSynthesis.speak(utterance);
    }
  };

  const progress = ((currentIndex + 1) / vocabularyDatabase.length) * 100;

  return (
    <div className={styles.home}>
      <header className={styles.header}>
        <h1 className={styles.appName}>VACA</h1>
        <div className={styles.headerActions}>
          <div className={styles.streakBadge}>
            <Flame className={styles.streakIcon} size={16} />
            {streak} day{streak !== 1 ? "s" : ""}
          </div>
          <Link to="/saved" className={styles.iconButton}>
            <Library size={20} />
          </Link>
          <Link to="/settings" className={styles.iconButton}>
            <Settings size={20} />
          </Link>
        </div>
      </header>

      <main className={styles.main}>
        <div className={styles.cardContainer} {...swipeHandlers}>
          <WordCard
            word={currentWord}
            isSwiping={swipeHandlers.swipeProgress > 0}
            swipeDirection={swipeHandlers.swipeDirection}
          />
        </div>
      </main>

      <footer className={styles.footer}>
        <div className={styles.controls}>
          <button className={styles.iconButton} onClick={handlePrevious} aria-label="Previous word">
            <ChevronLeft size={24} />
          </button>

          <button
            className={classNames(styles.iconButton, { [styles.active]: isBookmarked })}
            onClick={toggleBookmark}
            aria-label={isBookmarked ? "Remove bookmark" : "Add bookmark"}
          >
            <Bookmark size={24} fill={isBookmarked ? "currentColor" : "none"} />
          </button>

          <button className={styles.speakerButton} onClick={speak} aria-label="Pronounce word">
            <Volume2 size={24} />
          </button>

          <button className={styles.iconButton} onClick={handleNext} aria-label="Next word">
            <ChevronRight size={24} />
          </button>
        </div>

        <p className={styles.swipeHint}>
          <ChevronLeft size={16} />
          Swipe to navigate
          <ChevronRight size={16} />
        </p>

        <div className={styles.progressContainer}>
          <div className={styles.progressBar}>
            <div className={styles.progressFill} style={{ width: `${progress}%` }} />
          </div>
          <p className={styles.progressText}>
            {currentIndex + 1} of {vocabularyDatabase.length} • {wordsLearnedToday} learned today
          </p>
        </div>
      </footer>
    </div>
  );
}
