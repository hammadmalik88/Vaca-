import { useState } from "react";
import type { VocabularyWord } from "~/data/vocabulary";
import { ChevronDown, ChevronUp } from "lucide-react";
import classNames from "classnames";
import styles from "./word-card.module.css";

interface WordCardProps {
  /**
   * The vocabulary word data to display
   * @important
   */
  word: VocabularyWord;
  /**
   * Whether the card is currently being swiped
   */
  isSwiping?: boolean;
  /**
   * Direction of the swipe
   */
  swipeDirection?: "left" | "right" | null;
  className?: string;
}

export function WordCard({ word, isSwiping, swipeDirection, className }: WordCardProps) {
  const [showExample, setShowExample] = useState(false);
  const [showEtymology, setShowEtymology] = useState(false);

  return (
    <div
      className={classNames(
        styles.card,
        {
          [styles.cardSwiping]: isSwiping,
          [styles.cardSwipeLeft]: swipeDirection === "left",
          [styles.cardSwipeRight]: swipeDirection === "right",
        },
        className,
      )}
    >
      <div className={styles.categoryBadge}>{word.category}</div>
      <div className={classNames(styles.difficultyBadge, styles[word.difficulty.toLowerCase()])}>{word.difficulty}</div>

      <h1 className={styles.word}>{word.word}</h1>
      <p className={styles.partOfSpeech}>{word.partOfSpeech}</p>
      <p className={styles.meaning}>{word.meaning}</p>
      <p className={styles.pronunciation}>/{word.pronunciation}/</p>

      <div className={styles.exampleSection}>
        <button className={styles.exampleToggle} onClick={() => setShowExample(!showExample)}>
          {showExample ? "Hide" : "Show"} Example
        </button>
        {showExample && <p className={styles.example}>"{word.example}"</p>}
      </div>

      {word.etymology && (
        <div className={styles.etymologySection}>
          <button className={styles.etymologyToggle} onClick={() => setShowEtymology(!showEtymology)}>
            {showEtymology ? (
              <ChevronUp className={styles.icon} size={16} />
            ) : (
              <ChevronDown className={styles.icon} size={16} />
            )}
            Origin
          </button>
          {showEtymology && <p className={styles.etymology}>{word.etymology}</p>}
        </div>
      )}
    </div>
  );
}
