import { useState, useRef, useCallback } from "react";

interface SwipeInput {
  onSwipeLeft?: () => void;
  onSwipeRight?: () => void;
}

interface SwipeOutput {
  onTouchStart: (e: React.TouchEvent) => void;
  onTouchMove: (e: React.TouchEvent) => void;
  onTouchEnd: () => void;
  swipeDirection: "left" | "right" | null;
  swipeProgress: number;
}

const MIN_SWIPE_DISTANCE = 50;

export function useSwipe({ onSwipeLeft, onSwipeRight }: SwipeInput): SwipeOutput {
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);
  const [swipeDirection, setSwipeDirection] = useState<"left" | "right" | null>(null);
  const [swipeProgress, setSwipeProgress] = useState(0);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    setTouchEnd(null);
    setTouchStart(e.targetTouches[0].clientX);
    setSwipeDirection(null);
    setSwipeProgress(0);
  }, []);

  const onTouchMove = useCallback(
    (e: React.TouchEvent) => {
      if (touchStart === null) return;

      const currentTouch = e.targetTouches[0].clientX;
      setTouchEnd(currentTouch);

      const distance = touchStart - currentTouch;
      const progress = Math.min(Math.abs(distance) / 200, 1);
      setSwipeProgress(progress);

      if (distance > 10) {
        setSwipeDirection("left");
      } else if (distance < -10) {
        setSwipeDirection("right");
      }
    },
    [touchStart],
  );

  const onTouchEnd = useCallback(() => {
    if (!touchStart || !touchEnd) {
      setSwipeDirection(null);
      setSwipeProgress(0);
      return;
    }

    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > MIN_SWIPE_DISTANCE;
    const isRightSwipe = distance < -MIN_SWIPE_DISTANCE;

    if (isLeftSwipe && onSwipeLeft) {
      onSwipeLeft();
    } else if (isRightSwipe && onSwipeRight) {
      onSwipeRight();
    }

    setTouchStart(null);
    setTouchEnd(null);
    setSwipeDirection(null);
    setSwipeProgress(0);
  }, [touchStart, touchEnd, onSwipeLeft, onSwipeRight]);

  return {
    onTouchStart,
    onTouchMove,
    onTouchEnd,
    swipeDirection,
    swipeProgress,
  };
}
